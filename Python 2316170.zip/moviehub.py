import json

class Movie:
    def __init__(self, title, director, year, genre):
        self.title = title
        self.director = director
        self.year = year
        self.genre = genre

class MovieCollection:
    def __init__(self):
        self.movies = []

    def add_movie(self, movie):
        self.movies.append(movie)

    def remove_movie(self, title):
        for movie in self.movies:
            if movie.title == title:
                self.movies.remove(movie)
                print(f"{title} has been removed from the collection.")
                return
        print(f"Error: {title} not found in the collection.")

    def display_movies(self):
        if not self.movies:
            print("*******************************************")
            print("The movie collection is empty.")
            print("*******************************************")
        else:
            print("Movie Collection:")
            print("*********************")
            for movie in self.movies:
                print(f" Title: {movie.title}\n Director: {movie.director}\n Year: {movie.year}\n Genre: {movie.genre}")
                print("--------------------")
            print("*********************")

    def save_to_file(self, filename):
        with open(filename, 'w') as file:
            json.dump([vars(movie) for movie in self.movies], file, indent=4)
        print("Movie collection saved to", filename)

    def load_from_file(self, filename):
        try:
            with open(filename, 'r') as file:
                data = json.load(file)
                self.movies = [Movie(**movie_data) for movie_data in data]
            print("Movie collection loaded from", filename)
        except FileNotFoundError:
            print("File not found.")
        except json.JSONDecodeError:
            print("Invalid JSON format.")

    def search_movies(self, choice, query):
        found_movies = []
        if choice == '4':  # Search by title
            found_movies = [movie for movie in self.movies if query.lower() in movie.title.lower()]
        elif choice == '5':  # Search by director
            found_movies = [movie for movie in self.movies if query.lower() in movie.director.lower()]
        elif choice == '6':  # Search by year
            found_movies = [movie for movie in self.movies if query == str(movie.year)]
        elif choice == '7':  # Search by genre
            found_movies = [movie for movie in self.movies if query.lower() in movie.genre.lower()]

        if not found_movies:
            print("No movies found matching the query.")
        else:
            print("Matching Movies:")
            print("*********************")
            for movie in found_movies:
                print(f" Title: {movie.title} \nDirector: {movie.director} \nYear: {movie.year} \nGenre: {movie.genre}")
                print("--------------------")
            print("*********************")

def main():
    collection = MovieCollection()

    while True:
        print("\nxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        print("Movie Collection Management System")
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
        print("1. Add a movie")
        print("2. Remove a movie")
        print("3. Display all movies")
        print("4. Search for a movie by Title")
        print("5. Search for a movie by Director")
        print("6. Search for a movie by Year")
        print("7. Search for a movie by Genre")
        print("8. Save collection to file")
        print("9. Load collection from file")
        print("10. Quit")
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")

        choice = input("Enter your choice: ")
        print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n")

        if choice == '1':
            title = input("Enter movie title: ")
            director = input("Enter director name: ")
            year = int(input("Enter release year: "))
            genre = input("Enter genre: ")
            movie = Movie(title, director, year, genre)
            collection.add_movie(movie)

        elif choice == '2':
            title = input("Enter the title of the movie to remove: ")
            collection.remove_movie(title)

        elif choice == '3':
            collection.display_movies()

        elif choice in ['4', '5', '6', '7']:
            query = input(f"Enter search query for {'Title' if choice == '4' else 'Director' if choice == '5' else 'Year' if choice == '6' else 'Genre'}: ")
            collection.search_movies(choice, query)

        elif choice == '8':
            filename = input("Enter the filename to save: ")
            collection.save_to_file(filename)

        elif choice == '9':
            filename = input("Enter the filename to load: ")
            collection.load_from_file(filename)

        elif choice == '10':
            print("Exiting the program. Goodbye!")
            print("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx")
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 10.")

if __name__ == "__main__":
    main()
